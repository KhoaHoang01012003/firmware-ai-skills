#!/usr/bin/env bash
set -u

STRICT=0
NO_COLOR=0

usage() {
  cat <<'EOF'
Usage: bash scripts/verify-environment.sh [options]

Checks repository structure and useful firmware emulation tooling.

Options:
  --strict     Exit non-zero when recommended tools are missing.
  --no-color   Disable colored output.
  -h, --help   Show this help text.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --strict)
      STRICT=1
      shift
      ;;
    --no-color)
      NO_COLOR=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ "$NO_COLOR" -eq 0 && -t 1 ]]; then
  GREEN="$(printf '\033[32m')"
  YELLOW="$(printf '\033[33m')"
  RED="$(printf '\033[31m')"
  RESET="$(printf '\033[0m')"
else
  GREEN=""
  YELLOW=""
  RED=""
  RESET=""
fi

PASS=0
WARN=0
FAIL=0

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

ok() {
  PASS=$((PASS + 1))
  printf '%s[OK]%s %s\n' "$GREEN" "$RESET" "$*"
}

warn() {
  WARN=$((WARN + 1))
  printf '%s[WARN]%s %s\n' "$YELLOW" "$RESET" "$*"
}

fail() {
  FAIL=$((FAIL + 1))
  printf '%s[FAIL]%s %s\n' "$RED" "$RESET" "$*"
}

has_cmd() {
  command -v "$1" >/dev/null 2>&1
}

check_cmd() {
  local name="$1"
  local level="${2:-recommended}"
  local hint="${3:-}"

  if has_cmd "$name"; then
    local path
    path="$(command -v "$name")"
    ok "$name found at $path"
  elif [[ "$level" == "required" ]]; then
    fail "$name is missing${hint:+ ($hint)}"
  else
    warn "$name is missing${hint:+ ($hint)}"
  fi
}

check_any_cmd() {
  local label="$1"
  local level="$2"
  shift 2
  local cmd

  for cmd in "$@"; do
    if has_cmd "$cmd"; then
      ok "$label available via $cmd"
      return
    fi
  done

  if [[ "$level" == "required" ]]; then
    fail "$label missing; checked: $*"
  else
    warn "$label missing; checked: $*"
  fi
}

expected_skills=(
  firmware-start
  firmware-artifact-contract
  firmware-intake-normalization
  firmware-binary-service-inventory
  firmware-attack-surface-graph
  firmware-input-path-discovery
  firmware-discovery-orchestrator
  firmware-service-state-discovery
  firmware-service-emulation
  firmware-runtime-observation
  firmware-debugging
  firmware-memory-layer
)

section() {
  printf '\n== %s ==\n' "$*"
}

section "Repository structure"

if [[ -f "$repo_root/README.md" ]]; then
  ok "README.md exists"
else
  fail "README.md is missing"
fi

for platform in codex claude; do
  if [[ -d "$repo_root/$platform" ]]; then
    ok "$platform/ directory exists"
  else
    fail "$platform/ directory is missing"
    continue
  fi

  for skill in "${expected_skills[@]}"; do
    if [[ -f "$repo_root/$platform/$skill/SKILL.md" ]]; then
      ok "$platform/$skill/SKILL.md exists"
    else
      fail "$platform/$skill/SKILL.md is missing"
    fi
  done
done

if find "$repo_root/claude" -path '*/agents/openai.yaml' -print -quit 2>/dev/null | grep -q .; then
  fail "Claude skills contain agents/openai.yaml metadata; remove OpenAI/Codex-specific agent metadata from claude/"
else
  ok "Claude skills do not contain agents/openai.yaml metadata"
fi

if grep -R -n -E 'model: gpt-|reasoning_effort|openai.yaml' "$repo_root/claude" >/dev/null 2>&1; then
  fail "Claude skills contain OpenAI/Codex-specific metadata strings"
else
  ok "Claude skills do not contain OpenAI/Codex-specific metadata strings"
fi

section "Skill helper scripts"

for script in \
  "$repo_root/codex/firmware-artifact-contract/scripts/validate_artifact.py" \
  "$repo_root/codex/firmware-memory-layer/scripts/suggest_memory.py" \
  "$repo_root/codex/firmware-memory-layer/scripts/validate_memory.py" \
  "$repo_root/codex/firmware-memory-layer/scripts/promote_memory.py"; do
  if [[ -f "$script" ]]; then
    ok "helper script exists: ${script#$repo_root/}"
  else
    warn "helper script not found: ${script#$repo_root/}"
  fi
done

section "Required baseline"

check_cmd git required
check_cmd bash required
check_any_cmd "Python 3" required python3 python
check_cmd cp recommended
check_cmd find recommended

section "Firmware intake and extraction"

check_cmd file recommended
check_cmd binwalk recommended
check_any_cmd "7-Zip CLI" recommended 7z 7za 7zr
check_cmd unsquashfs recommended "usually provided by squashfs-tools"
check_cmd cpio recommended
check_cmd tar recommended
check_any_cmd "XZ decompressor" recommended xz unxz
check_cmd losetup recommended "usually provided by util-linux"
check_cmd kpartx recommended
check_cmd rauc recommended "needed for .raucb bundles"

section "QEMU and runtime"

check_cmd qemu-img recommended
check_cmd qemu-system-x86_64 recommended
check_cmd qemu-system-aarch64 recommended
check_cmd qemu-system-arm recommended
check_cmd qemu-system-mips recommended
check_any_cmd "QEMU user static for x86_64" recommended qemu-x86_64-static qemu-x86_64
check_any_cmd "QEMU user static for aarch64" recommended qemu-aarch64-static qemu-aarch64
check_any_cmd "QEMU user static for ARM" recommended qemu-arm-static qemu-arm
check_any_cmd "QEMU user static for MIPS" recommended qemu-mips-static qemu-mips qemu-mipsel-static qemu-mipsel
check_cmd ip recommended "usually provided by iproute2"
check_any_cmd "Firewall/NAT tooling" recommended iptables nft
check_any_cmd "Netcat" recommended nc netcat ncat
check_cmd socat recommended
check_cmd curl recommended
check_cmd jq recommended
check_cmd openssl recommended

if [[ -e /dev/kvm ]]; then
  if [[ -r /dev/kvm && -w /dev/kvm ]]; then
    ok "/dev/kvm exists and is readable/writable by this user"
  else
    warn "/dev/kvm exists but current user may not have access"
  fi
else
  warn "/dev/kvm not found; QEMU can still run, but hardware acceleration may be unavailable"
fi

section "Runtime observation and debugging"

check_cmd gdb recommended
check_cmd gdb-multiarch recommended
check_cmd gdbserver recommended
check_cmd strace recommended
check_cmd ltrace recommended
check_cmd tcpdump recommended
check_cmd tshark recommended
check_cmd frida recommended
check_cmd bpftrace recommended

section "Optional static analysis and pentest enrichment"

check_cmd readelf recommended
check_cmd objdump recommended
check_cmd strings recommended
check_any_cmd "radare2/rizin binary analysis" recommended rabin2 rizin rz-bin r2
check_any_cmd "Ghidra headless analyzer" recommended analyzeHeadless ghidra-analyzeHeadless
check_cmd semgrep recommended
check_cmd cve-bin-tool recommended
check_cmd syft recommended
check_cmd grype recommended
check_cmd trivy recommended
check_cmd nmap recommended
check_cmd whatweb recommended
check_cmd httpx recommended

section "Python helper syntax"

if has_cmd python3 || has_cmd python; then
  pycmd="python3"
  if ! has_cmd python3; then
    pycmd="python"
  fi

  py_scripts=(
    "$repo_root/codex/firmware-artifact-contract/scripts/validate_artifact.py"
    "$repo_root/codex/firmware-memory-layer/scripts/suggest_memory.py"
    "$repo_root/codex/firmware-memory-layer/scripts/validate_memory.py"
    "$repo_root/codex/firmware-memory-layer/scripts/promote_memory.py"
  )

  for script in "${py_scripts[@]}"; do
    if [[ -f "$script" ]]; then
      if "$pycmd" - "$script" >/dev/null 2>&1 <<'PY'
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
compile(path.read_text(encoding="utf-8"), str(path), "exec")
PY
      then
        ok "Python syntax OK: ${script#$repo_root/}"
      else
        fail "Python syntax check failed: ${script#$repo_root/}"
      fi
    fi
  done
else
  fail "Python is unavailable; cannot validate helper scripts"
fi

section "Summary"

printf 'Passed: %s\n' "$PASS"
printf 'Warnings: %s\n' "$WARN"
printf 'Failures: %s\n' "$FAIL"

if [[ "$FAIL" -gt 0 ]]; then
  exit 1
fi

if [[ "$STRICT" -eq 1 && "$WARN" -gt 0 ]]; then
  exit 1
fi

exit 0
