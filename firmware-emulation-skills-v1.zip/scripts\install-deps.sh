#!/usr/bin/env bash
set -euo pipefail

DRY_RUN=0
WITH_PYTHON_TOOLS=0

usage() {
  cat <<'EOF'
Usage: bash scripts/install-deps.sh [options]

Best-effort dependency installer for the Firmware Emulation AI Dual Skills repo.

Options:
  --dry-run             Print commands without installing packages.
  --with-python-tools   Also try to install optional Python tools with pipx/pip.
  -h, --help            Show this help text.

Supported package managers:
  apt-get, dnf, pacman, brew

Notes:
  - Debian/Ubuntu/WSL2 is the best-supported target.
  - macOS/Homebrew installs a host-side subset; Linux or WSL2 is still recommended
    for full-system firmware emulation.
  - Advanced tools such as Ghidra, CodeQL, Joern, EMBA, FACT, Syft, Grype, and
    Trivy may need separate project-specific installation steps.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    --with-python-tools)
      WITH_PYTHON_TOOLS=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

log() {
  printf '[install-deps] %s\n' "$*"
}

warn() {
  printf '[install-deps][warn] %s\n' "$*" >&2
}

run() {
  if [[ "$DRY_RUN" -eq 1 ]]; then
    printf '+ %s\n' "$*"
  else
    eval "$@"
  fi
}

need_sudo() {
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    SUDO=""
  elif command -v sudo >/dev/null 2>&1; then
    SUDO="sudo"
  else
    warn "This system needs root privileges, but sudo was not found."
    warn "Re-run as root or install sudo first."
    exit 1
  fi
}

install_each() {
  local installer="$1"
  shift
  local pkg

  for pkg in "$@"; do
    log "Installing package: $pkg"
    if [[ "$DRY_RUN" -eq 1 ]]; then
      printf '+ %s %s\n' "$installer" "$pkg"
      continue
    fi

    if ! eval "$installer \"\$pkg\""; then
      warn "Package install failed or package not available: $pkg"
    fi
  done
}

install_python_tools() {
  if [[ "$WITH_PYTHON_TOOLS" -ne 1 ]]; then
    return
  fi

  local python_cmd=""
  if command -v python3 >/dev/null 2>&1; then
    python_cmd="python3"
  elif command -v python >/dev/null 2>&1; then
    python_cmd="python"
  else
    warn "Python is not available; skipping optional Python tools."
    return
  fi

  local tools=(semgrep frida-tools cve-bin-tool)

  if command -v pipx >/dev/null 2>&1; then
    local tool
    for tool in "${tools[@]}"; do
      log "Installing optional Python tool with pipx: $tool"
      if [[ "$DRY_RUN" -eq 1 ]]; then
        printf '+ pipx install %s\n' "$tool"
      else
        pipx install "$tool" || warn "pipx install failed: $tool"
      fi
    done
    return
  fi

  warn "pipx not found. Falling back to user-level pip install for optional Python tools."
  for tool in "${tools[@]}"; do
    log "Installing optional Python tool with pip --user: $tool"
    if [[ "$DRY_RUN" -eq 1 ]]; then
      printf '+ %s -m pip install --user %s\n' "$python_cmd" "$tool"
    else
      "$python_cmd" -m pip install --user "$tool" || warn "pip install failed: $tool"
    fi
  done
}

install_apt() {
  need_sudo
  run "$SUDO apt-get update"

  local packages=(
    ca-certificates git bash python3 python3-pip python3-venv python3-jsonschema
    jq curl file p7zip-full binwalk squashfs-tools cpio tar gzip xz-utils
    e2fsprogs util-linux kpartx
    qemu-system qemu-user-static qemu-utils
    iproute2 iptables nftables tcpdump
    gdb gdb-multiarch gdbserver strace ltrace
    openssl socat netcat-openbsd
    nmap
  )

  install_each "$SUDO apt-get install -y" "${packages[@]}"

  if apt-cache show rauc >/dev/null 2>&1; then
    install_each "$SUDO apt-get install -y" rauc
  else
    warn "Package rauc is not available in the configured apt repositories."
  fi
}

install_dnf() {
  need_sudo

  local packages=(
    ca-certificates git bash python3 python3-pip
    jq curl file p7zip p7zip-plugins binwalk squashfs-tools cpio tar gzip xz
    e2fsprogs util-linux kpartx
    qemu-system-x86 qemu-system-arm qemu-user-static qemu-img
    iproute iptables nftables tcpdump
    gdb gdb-gdbserver strace ltrace
    openssl socat nmap-ncat nmap
  )

  install_each "$SUDO dnf install -y" "${packages[@]}"
}

install_pacman() {
  need_sudo
  run "$SUDO pacman -Sy --noconfirm"

  local packages=(
    ca-certificates git bash python python-pip
    jq curl file p7zip binwalk squashfs-tools cpio tar gzip xz
    e2fsprogs util-linux
    qemu-full qemu-user-static
    iproute2 iptables-nft nftables tcpdump
    gdb strace ltrace
    openssl socat gnu-netcat nmap
  )

  install_each "$SUDO pacman -S --needed --noconfirm" "${packages[@]}"
  warn "If you need kpartx on Arch, install multipath-tools if available for your setup."
}

install_brew() {
  if ! command -v brew >/dev/null 2>&1; then
    warn "Homebrew was not found. Install it from https://brew.sh/ or use a Linux/WSL2 environment."
    exit 1
  fi

  local packages=(
    git bash python jq curl file-formula p7zip binwalk squashfs
    qemu gdb openssl socat nmap
  )

  install_each "brew install" "${packages[@]}"
  warn "macOS is useful for host-side tooling, but Linux/WSL2 is recommended for full-system firmware emulation."
}

main() {
  if command -v apt-get >/dev/null 2>&1; then
    log "Detected apt-get."
    install_apt
  elif command -v dnf >/dev/null 2>&1; then
    log "Detected dnf."
    install_dnf
  elif command -v pacman >/dev/null 2>&1; then
    log "Detected pacman."
    install_pacman
  elif command -v brew >/dev/null 2>&1; then
    log "Detected Homebrew."
    install_brew
  else
    warn "No supported package manager found."
    warn "Install the dependencies listed in README.md manually."
    exit 1
  fi

  install_python_tools

  log "Dependency installation attempt finished."
  log "Run: bash scripts/verify-environment.sh"
}

main "$@"
