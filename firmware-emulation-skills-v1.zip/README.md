# Firmware Emulation AI Dual Skills

This repository contains a firmware emulation skill set for both Codex and Claude.

The skill set is designed to guide an AI agent through a practical firmware emulation workflow: identify the firmware, normalize the extracted filesystem, inventory binaries and services, understand service dependencies, bring up an emulation/runtime environment, observe real behavior, and debug runtime failures when services do not work correctly.

## Included Skills

| Skill | Purpose |
| --- | --- |
| `firmware-start` | Entry point for a raw firmware file or extracted directory. Turns a short request into a structured firmware analysis goal. |
| `firmware-artifact-contract` | Defines shared artifact rules, evidence labels, schema expectations, warnings, errors, and readiness gates. |
| `firmware-intake-normalization` | Normalizes firmware identity: hashes, format, extraction state, rootfs candidates, model/version hints, and architecture hints. |
| `firmware-binary-service-inventory` | Inventories binaries, scripts, interpreters, libraries, init paths, daemons, port hints, and service candidates. |
| `firmware-attack-surface-graph` | Connects services to input vectors, parsers, sinks, privileges, and authentication boundaries. |
| `firmware-input-path-discovery` | Discovers controllable inputs such as HTTP routes, CLI, IPC, config files, environment variables, update packages, and network messages. |
| `firmware-discovery-orchestrator` | Central coordinator. Reads current artifacts, identifies missing evidence, and chooses the next skill. |
| `firmware-service-state-discovery` | Maps runtime requirements: files, configs, data directories, ports/sockets, credentials, dependency services, and hardware/simulator state. |
| `firmware-service-emulation` | Builds the runtime lane: full-system QEMU, qemu-user, chroot, container, proxy, or another scoped execution mode. |
| `firmware-runtime-observation` | Observes real behavior through workloads such as API calls, IPC, CLI, packet flow, log effects, browser paths, login, or read-only feature use. |
| `firmware-debugging` | Finds root cause for crashes, missing listeners, broken IPC/WebSocket paths, failed dependencies, and unexplained `500`/`502`/`404` behavior. |
| `firmware-memory-layer` | Turns validated experience into reusable patterns without storing secrets or replacing current-case validation. |

## Repository Layout

```text
.
+-- codex/
|   +-- firmware-*/
+-- claude/
|   +-- firmware-*/
+-- scripts/
|   +-- install-deps.sh
|   +-- verify-environment.sh
+-- README.md
```

Each skill must contain `SKILL.md`.

For Codex skills, optional `agents/openai.yaml` metadata may exist when Codex-specific model or UI hints are useful.

For Claude skills, do not include OpenAI/Codex metadata such as `agents/openai.yaml`, `model: gpt-*`, or `reasoning_effort`. Claude skills should keep the standard `SKILL.md` plus supporting files layout.

## Clone

Replace the URL with your Gitea repository URL:

```bash
git clone https://gitea.example.com/your-org/firmware-ai-dual-skills.git
cd firmware-ai-dual-skills
```

## Install Skills Into Codex

Linux, macOS, or WSL:

```bash
mkdir -p ~/.codex/skills
cp -R codex/firmware-* ~/.codex/skills/
```

Windows PowerShell:

```powershell
New-Item -ItemType Directory -Force "$env:USERPROFILE\.codex\skills" | Out-Null
Copy-Item .\codex\firmware-* "$env:USERPROFILE\.codex\skills" -Recurse -Force
```

Restart Codex after copying the skills.

## Install Skills Into Claude

Linux, macOS, or WSL:

```bash
mkdir -p ~/.claude/skills
cp -R claude/firmware-* ~/.claude/skills/
```

Windows PowerShell:

```powershell
New-Item -ItemType Directory -Force "$env:USERPROFILE\.claude\skills" | Out-Null
Copy-Item .\claude\firmware-* "$env:USERPROFILE\.claude\skills" -Recurse -Force
```

Restart Claude after copying the skills.

## Usage

Start from a firmware file:

```text
Use firmware-start to analyze and emulate /path/to/firmware.bin.
Goal: full-system or best-supported emulation, service readiness, host-reachable UI/API if present, auth handling if credentials are available, and representative workload validation. Write blockers instead of guessing.
```

Start from firmware with a web UI or WBM:

```text
Use firmware-start for /path/to/firmware.raucb.
Goal: bring up required services, expose the real UI to the host browser, verify login/auth flow with provided credentials, validate representative read-only feature/API routes, and create start/stop/restart scripts. Do not mark success while required routes still return unexplained 500/502/404.
```

Continue an unfinished firmware emulation session:

```text
Use firmware-start to continue the current firmware emulation workspace.
Resume from the latest artifacts, preserve the previous success gate, and route to the next required firmware skill instead of restarting from scratch.
```

Debug a broken runtime or service:

```text
Use firmware-debugging and firmware-runtime-observation to root-cause why the emulated service returns 500/502/404. Preserve logs, direct backend checks, process/port state, and config/dependency evidence.
```

## Install Dependencies

The skills can be imported without external firmware tools, but real firmware emulation usually needs QEMU, extraction tools, debugging tools, and runtime observation tools.

Run the installer:

```bash
bash scripts/install-deps.sh
```

Preview installation commands without changing the system:

```bash
bash scripts/install-deps.sh --dry-run
```

Install optional Python security tools as well:

```bash
bash scripts/install-deps.sh --with-python-tools
```

The installer supports common Linux-like environments through `apt-get`, `dnf`, `pacman`, and a smaller macOS/Homebrew host-side tool subset.

## Verify Installation

Check repository structure, skill files, helper scripts, and useful firmware emulation tools:

```bash
bash scripts/verify-environment.sh
```

Use strict mode if missing recommended tools should return a non-zero exit code:

```bash
bash scripts/verify-environment.sh --strict
```
